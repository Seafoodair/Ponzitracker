import json
import networkx as nx
import torch
import torch.nn.functional as F
from torch_geometric.utils import from_networkx
from torch_geometric.nn import GCNConv

# 示例数据
data = '''{
    "edges": [
        {
            "from": "0xab914e7b04f1b6ed397dbce175eec827563c91bd",
            "to": "",
            "value": "0",
            "from_balance": 3.897496215369773e-17,
            "to_balance": null
        },
        {
            "from": "0xab914e7b04f1b6ed397dbce175eec827563c91bd",
            "to": "0xf1aa63ad7a897ca02cab6021513ee0a86820153e",
            "value": "1000000000000000",
            "from_balance": 3.897034455369773e-17,
            "to_balance": 0.001
        }
    ]
}'''

json_data = json.loads(data)
edges = json_data['edges']

# 创建图结构
G = nx.DiGraph()

for edge in edges:
    from_node = edge['from']
    to_node = edge['to']
    value = float(edge['value'])

    # 添加节点
    G.add_node(from_node, balance=edge['from_balance'])
    if to_node:
        G.add_node(to_node, balance=edge['to_balance'])

    # 添加边
    if to_node:
        G.add_edge(from_node, to_node, weight=value)

# 转换为PyTorch Geometric数据格式
data = from_networkx(G)

# 添加节点特征（例如余额）
node_features = []
for node, attributes in G.nodes(data=True):
    node_features.append([attributes['balance']])
data.x = torch.tensor(node_features, dtype=torch.float)

# 边权重（例如交易金额）
edge_weights = [G[u][v]['weight'] for u, v in G.edges()]
data.edge_attr = torch.tensor(edge_weights, dtype=torch.float)


# 定义GCN模型
class GCN(torch.nn.Module):
    def __init__(self, num_node_features, hidden_channels):
        super(GCN, self).__init__()
        self.conv1 = GCNConv(num_node_features, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        return x


# 创建模型
model = GCN(num_node_features=1, hidden_channels=16)

# 打印模型输出（用于测试）
model.eval()
output = model(data)
print(output.shape)
